# AI Clipper Indonesia — Proyek Android (prototipe)

Ini adalah **proyek sumber Android Studio**, bukan APK siap pasang. Prototipe ini menyediakan antarmuka awal dan validasi format URL YouTube. Mesin AI untuk transkripsi, pemilihan momen, pemotongan, subtitle, dan ekspor MP4 **belum diimplementasikan**.

## Persyaratan
- Komputer Windows/macOS/Linux
- Android Studio versi yang mendukung Android Gradle Plugin 8.7.3
- JDK 17
- Android SDK Platform 35

> Proyek ini belum bisa dibangun langsung dari HP Android. Untuk menghasilkan APK, buka proyek ini di Android Studio pada komputer.

## Cara membuka dan membangun APK
1. Ekstrak ZIP.
2. Android Studio → Open → pilih folder `AIClipperIndonesia`.
3. Tunggu Gradle Sync selesai.
4. Pilih Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK debug akan muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Status fitur
- [x] Tampilan awal aplikasi Android
- [x] Kolom link YouTube
- [x] Validasi format URL
- [ ] Pengambilan video: tidak disediakan. Gunakan hanya sumber video yang kamu miliki/diizinkan dan alur resmi yang memperbolehkan pengunduhan.
- [ ] Transkripsi Whisper bahasa Indonesia
- [ ] Penilaian momen menarik
- [ ] Pemotongan video FFmpeg / Media3
- [ ] Subtitle SRT/ASS
- [ ] Crop vertikal 9:16 dan ekspor MP4

## Arsitektur yang disarankan untuk versi berikutnya
1. Input sumber video yang pengguna berhak olah (file lokal atau sumber resmi yang menyediakan unduhan).
2. Ekstrak audio secara lokal.
3. Jalankan Whisper.cpp model multilingual untuk membuat transkrip bertimestamp.
4. Skor segmen berdasarkan kalimat lengkap, kata kunci, pergantian pembicara, dan durasi.
5. Render segmen dengan Media3 Transformer atau FFmpeg yang kompatibel dengan Android.
6. Burn subtitle dan ekspor MP4 vertikal.

## Catatan penting
- Jangan gunakan aplikasi ini untuk mengambil atau menerbitkan ulang podcast orang lain tanpa izin.
- URL YouTube saja tidak otomatis memberikan hak untuk mengunduh atau memublikasikan ulang videonya.
- Proses AI lokal bisa berat dan memerlukan ruang penyimpanan serta RAM yang cukup.
