package id.ai.clipper

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(18, 20, 24)
    private val panel = Color.rgb(34, 37, 43)
    private val lime = Color.rgb(190, 242, 100)
    private lateinit var urlInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.setBackgroundColor(bg)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(22))
        }

        val title = TextView(this).apply {
            text = "✂  AI CLIPPER\n     INDONESIA"
            textSize = 27f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        page.addView(title)
        page.addView(label("Buat klip podcast pendek secara otomatis"))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        val inputLabel = label("LINK VIDEO YOUTUBE")
        card.addView(inputLabel)

        urlInput = EditText(this).apply {
            hint = "Tempel link YouTube di sini"
            textSize = 15f
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(48, 52, 59))
        }
        card.addView(urlInput, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(54)
        ).apply { topMargin = dp(10) })

        val note = TextView(this).apply {
            text = "Gunakan video milik sendiri atau yang kamu punya izin untuk diolah. Aplikasi ini tidak mengunduh video YouTube atau melewati pembatasan hak cipta."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(12), 0, dp(12))
        }
        card.addView(note)

        val analyze = Button(this).apply {
            text = "Periksa link video"
            setTextColor(Color.BLACK)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(lime))
            setOnClickListener { checkUrl() }
        }
        card.addView(analyze, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
        ))
        page.addView(card, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(26) })

        status = TextView(this).apply {
            text = "STATUS: Menunggu link"
            textSize = 14f
            setTextColor(lime)
            setPadding(0, dp(22), 0, dp(10))
        }
        page.addView(status)

        val features = TextView(this).apply {
            text = "FITUR RENCANA\n\n✓ Subtitle bahasa Indonesia\n✓ Pemilihan momen menarik dengan AI\n✓ Klip vertikal 9:16\n✓ Ekspor MP4\n\nVersi 0.1 — prototipe antarmuka"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        page.addView(features)
        page.addView(label("Mesin AI/transkripsi dan ekspor video belum terpasang pada prototipe ini. Lihat README untuk tahap pengembangan berikutnya."))

        val scroll = ScrollView(this).apply { addView(page) }
        setContentView(scroll)
    }

    private fun checkUrl() {
        val raw = urlInput.text.toString().trim()
        val valid = raw.startsWith("https://www.youtube.com/") ||
                    raw.startsWith("https://youtu.be/") ||
                    raw.startsWith("https://m.youtube.com/")
        status.text = if (valid) {
            "LINK TERDETEKSI ✓\nLink valid secara format. Proses kliping belum tersedia di prototipe."
        } else {
            "Link belum dikenali. Tempel URL YouTube lengkap (youtube.com atau youtu.be)."
        }
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 13f
        setTextColor(Color.LTGRAY)
        setPadding(0, dp(10), 0, dp(6))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
